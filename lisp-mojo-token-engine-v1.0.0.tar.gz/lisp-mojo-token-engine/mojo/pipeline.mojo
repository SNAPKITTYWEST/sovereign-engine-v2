from arena import Arena
from scanner import Scanner
from vocab import Vocabulary
from bpe import MergeEngine

struct Pipeline:
    var arena: Arena
    var scanner: Scanner
    var vocab: Vocabulary

    fn __init__(inout self, capacity: Int = 8192):
        self.arena = Arena(capacity)
        self.scanner = Scanner(True)
        self.vocab = Vocabulary()

    fn add_merge(inout self, left: UInt32, right: UInt32, rank: UInt32, merged: UInt32):
        self.vocab.add(left, right, rank, merged)

    fn tokenize(inout self, input: String) -> List[UInt32]:
        self.arena.reset()
        let scanned = self.scanner.scan(input)
        let engine = MergeEngine(self.vocab)
        let result = engine.run(scanned)
        var ids = List[UInt32]()
        for t in result:
            ids.append(t.id)
        return ids

fn main() raises:
    var p = Pipeline()
    p.add_merge(97, 98, 0, 256)
    p.add_merge(256, 99, 1, 257)
    let ids = p.tokenize("abc")
    for id in ids:
        print(id)
