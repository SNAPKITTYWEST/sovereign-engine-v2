from types import PairRecord, make_pair_key

struct Vocabulary:
    var records: List[PairRecord]

    fn __init__(inout self):
        self.records = List[PairRecord]()

    fn add(inout self, left: UInt32, right: UInt32, rank: UInt32, merged: UInt32):
        self.records.append(PairRecord(left, right, rank, merged))

    fn lookup(self, left: UInt32, right: UInt32) -> Tuple[Bool, UInt32, UInt32]:
        let key = make_pair_key(left, right)
        var found = False
        var rank = UInt32.max
        var merged = UInt32(0)
        for r in self.records:
            if make_pair_key(r.left, r.right) == key and r.rank < rank:
                found = True
                rank = r.rank
                merged = r.merged
        return found, rank, merged
