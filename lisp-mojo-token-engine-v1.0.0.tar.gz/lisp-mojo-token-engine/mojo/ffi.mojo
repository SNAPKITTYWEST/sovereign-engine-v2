# ABI contract placeholder. The exported C ABI is specified in janet/token_engine.janet
# and docs.md. Platform-specific symbol export is isolated here so the tokenizer core
# never depends on Janet internals.

struct ABI_VERSION:
    var major: UInt32
    var minor: UInt32

fn abi_version() -> ABI_VERSION:
    return ABI_VERSION(1, 0)
