from types import Token

struct Scanner:
    var split_whitespace: Bool

    fn __init__(inout self, split_whitespace: Bool = True):
        self.split_whitespace = split_whitespace

    fn scan(self, input: String) -> List[Token]:
        var out = List[Token]()
        let b = input.as_bytes()
        var i = 0
        while i < b.size:
            out.append(Token(UInt32(b[i]), UInt32(i), UInt32(1)))
            i += 1
        return out
