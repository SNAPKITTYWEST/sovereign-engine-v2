struct Token:
    var id: UInt32
    var start: UInt32
    var length: UInt32
    var active: Bool

    fn __init__(inout self, id: UInt32, start: UInt32, length: UInt32):
        self.id = id
        self.start = start
        self.length = length
        self.active = True

struct PairRecord:
    var left: UInt32
    var right: UInt32
    var rank: UInt32
    var merged: UInt32

fn make_pair_key(left: UInt32, right: UInt32) -> UInt64:
    return (UInt64(left) << 32) | UInt64(right)
