struct Arena:
    var bytes: List[UInt8]
    var cursor: Int

    fn __init__(inout self, capacity: Int):
        self.bytes = List[UInt8](capacity=capacity)
        self.cursor = 0

    fn reset(inout self):
        self.cursor = 0

    fn reserve(inout self, count: Int) -> Int:
        let start = self.cursor
        self.cursor += count
        while self.bytes.size < self.cursor:
            self.bytes.append(0)
        return start
