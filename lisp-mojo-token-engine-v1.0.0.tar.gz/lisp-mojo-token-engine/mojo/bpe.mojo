from types import Token
from vocab import Vocabulary

struct MergeEngine:
    var vocab: Vocabulary

    fn __init__(inout self, vocab: Vocabulary):
        self.vocab = vocab

    fn run(self, input: List[Token]) -> List[Token]:
        var tokens = input
        while True:
            var best_index = -1
            var best_rank = UInt32.max
            var best_key = UInt64.max
            for i in range(tokens.size - 1):
                if not tokens[i].active or not tokens[i + 1].active:
                    continue
                let found, rank, _ = self.vocab.lookup(tokens[i].id, tokens[i + 1].id)
                if found:
                    let key = (UInt64(tokens[i].id) << 32) | UInt64(tokens[i + 1].id)
                    if rank < best_rank or (rank == best_rank and key < best_key):
                        best_index = i
                        best_rank = rank
                        best_key = key
            if best_index < 0:
                break
            let found, _, merged = self.vocab.lookup(tokens[best_index].id, tokens[best_index + 1].id)
            if not found:
                break
            let end = tokens[best_index + 1].start + tokens[best_index + 1].length
            tokens[best_index].id = merged
            tokens[best_index].length = end - tokens[best_index].start
            tokens[best_index + 1].active = False
        var result = List[Token]()
        for t in tokens:
            if t.active:
                result.append(t)
        return result
