(defun pipeline->ir (pipeline)
  (list :version 1 :pipeline pipeline))
