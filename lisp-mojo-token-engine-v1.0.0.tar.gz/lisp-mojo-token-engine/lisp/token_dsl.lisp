(defmacro token-pipeline (&rest clauses)
  `(list :token-pipeline :version 1 ,@clauses))

(defmacro input-spec (&key (encoding :utf8) (normalization :byte))
  `(:input (:encoding ,encoding) (:normalization ,normalization)))

(defmacro scanner-spec (&key (mode :byte) (split-whitespace true))
  `(:scanner (:mode ,mode) (:split-whitespace ,split-whitespace)))

(defmacro vocabulary-spec (&key path (format :pair-rank-v1))
  `(:vocabulary (:format ,format) (:path ,path)))

(defmacro merge-spec (&key (algorithm :bpe) (deterministic true))
  `(:merge (:algorithm ,algorithm) (:deterministic ,deterministic)))

(defmacro output-spec (&key (ids true) (offsets true))
  `(:output (:ids ,ids) (:offsets ,offsets)))

(def sample-pipeline
  (token-pipeline
    (input-spec :encoding :utf8 :normalization :byte)
    (scanner-spec :mode :byte :split-whitespace true)
    (vocabulary-spec :path "vocab.bin")
    (merge-spec :algorithm :bpe :deterministic true)
    (output-spec :ids true :offsets true)))
