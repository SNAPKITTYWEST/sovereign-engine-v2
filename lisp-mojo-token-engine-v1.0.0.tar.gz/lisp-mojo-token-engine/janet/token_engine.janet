(def VERSION "1.0.0")

(defn version [] VERSION)

# Native host integration is deliberately one boundary. The host loads the compiled
# library and binds tokenize/free according to docs.md. This module remains orchestration.
(defn tokenize [native text]
  (native :tokenize text))
