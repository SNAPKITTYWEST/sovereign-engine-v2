# Engineering Contract

## BPE
Pair key = `(left << 32) | right`. Lower rank wins. Equal ranks use pair-key order.
After a merge only the predecessor and successor pairs can change.

## Memory
Arena allocations are monotonic during one tokenization call and reset between calls.
Input spans do not own their source bytes.

## Vocabulary
The production format is a memory-mappable fixed-record table:
`left:u32 right:u32 rank:u32 merged:u32`.

## ABI
The C ABI returns `(token_id,start,length)` records and provides one release function.
No native exceptions cross the boundary.
