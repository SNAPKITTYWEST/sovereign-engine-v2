# LISP-MOJO Token Engine

A complete product-oriented deterministic tokenizer pipeline:

Lisp macro DSL -> canonical IR -> Mojo native core -> Janet FFI.

## Modules

- `lisp/` declarative macro front end and IR lowering
- `mojo/` scanner, arena, vocabulary, BPE engine, pipeline, ABI
- `janet/` orchestration and native boundary
- `tests/` deterministic vectors
- `tools/` vocabulary specification

## Runtime contract

The tokenizer is deterministic. Input bytes are scanned into zero-copy spans, vocabulary
pairs are ranked, and the lowest valid rank is merged until no candidate remains.

## Product boundary

Lisp describes the tokenizer. Mojo owns computation and memory. Janet owns application
orchestration. The ABI keeps the native core independent of the Janet runtime.

## Build

With Mojo installed:

`mojo build mojo/pipeline.mojo -o bin/token-engine`

The exact FFI command depends on the target platform and Janet installation.
