# Vocabulary Format v1

Each record is little-endian:

`left:u32 right:u32 rank:u32 merged:u32`

Pair key: `(left << 32) | right`.

Records can be memory mapped and indexed without copying the byte payload.
